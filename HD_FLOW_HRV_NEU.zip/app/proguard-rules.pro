# No shrinking rules needed for the first local build.
