package de.hd.flowhrv;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NightAudioService extends Service {
    public static final String ACTION_START = "de.hd.flowhrv.NIGHT_START";
    public static final String ACTION_STOP = "de.hd.flowhrv.NIGHT_STOP";
    public static final String ACTION_UPDATE = "de.hd.flowhrv.NIGHT_UPDATE";
    public static final String ACTION_STOPPED = "de.hd.flowhrv.NIGHT_STOPPED";

    private static final String CHANNEL_ID = "night_audio";
    private static final int NOTIFICATION_ID = 601;
    private static final String PREFS = "hd_flow_native";
    private static final String KEY_LAST_SESSION = "last_night_session";

    private static final int SAMPLE_RATE = 16000;
    private static volatile boolean running = false;
    private static volatile long startMs = 0L;
    private static volatile double currentDb = Double.NaN;
    private static volatile double thresholdDb = -48.0;
    private static volatile int eventCount = 0;
    private static volatile double coveragePct = 0.0;
    private static volatile String lastError = "";

    private AudioRecord audioRecord;
    private Thread captureThread;
    private volatile boolean stopRequested = false;
    private PowerManager.WakeLock wakeLock;

    private final ArrayDeque<Double> recentLevels = new ArrayDeque<>();
    private final JSONArray storedLevels = new JSONArray();
    private final JSONArray events = new JSONArray();
    private long quietStart = 0L;
    private boolean quietPreActive = false;
    private long lastActive = 0L;
    private long oneSecondSamples = 0L;
    private double oneSecondSquares = 0.0;
    private long processedSeconds = 0L;
    private long lastStoredSecond = -99L;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            stopCaptureAndFinish();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action) && !running) startCapture();
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        if (running) stopCaptureAndFinish();
        super.onDestroy();
    }

    public static boolean isRunning() { return running; }

    public static String getStatusJson() {
        try {
            JSONObject j = new JSONObject();
            j.put("running", running);
            j.put("startMs", startMs);
            j.put("db", Double.isFinite(currentDb) ? round1(currentDb) : JSONObject.NULL);
            j.put("threshold", Double.isFinite(thresholdDb) ? round1(thresholdDb) : JSONObject.NULL);
            j.put("events", eventCount);
            j.put("coverage", round1(coveragePct));
            j.put("elapsedSec", running && startMs > 0 ? Math.max(0, (System.currentTimeMillis() - startMs) / 1000) : 0);
            j.put("error", lastError == null ? "" : lastError);
            j.put("native", true);
            return j.toString();
        } catch (Exception e) {
            return "{\"running\":false,\"native\":true}";
        }
    }

    public static String getLastSessionJson(Context context) {
        return context.getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_LAST_SESSION, "");
    }

    public static String quickMicTest() {
        try {
            int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) return "{\"ok\":false,\"message\":\"AudioRecord nicht verfügbar.\"}";
            AudioRecord r = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, SAMPLE_RATE));
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                return "{\"ok\":false,\"message\":\"Mikrofon konnte nicht initialisiert werden.\"}";
            }
            short[] b = new short[2048];
            r.startRecording();
            int n = r.read(b, 0, b.length);
            r.stop();
            r.release();
            if (n <= 0) return "{\"ok\":false,\"message\":\"Mikrofon liefert keine Daten.\"}";
            double ss = 0;
            for (int i = 0; i < n; i++) { double x = b[i] / 32768.0; ss += x * x; }
            double rms = Math.sqrt(ss / n);
            double db = rms > 0 ? Math.max(-100.0, 20.0 * Math.log10(rms)) : -100.0;
            JSONObject j = new JSONObject();
            j.put("ok", true);
            j.put("db", round1(db));
            j.put("message", "Mikrofon funktioniert. Pegel " + round1(db) + " dB relativ.");
            return j.toString();
        } catch (Exception e) {
            try {
                JSONObject j = new JSONObject(); j.put("ok", false); j.put("message", e.getMessage()); return j.toString();
            } catch (Exception ignored) { return "{\"ok\":false}"; }
        }
    }

    private void startCapture() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastError = "Mikrofon-Berechtigung fehlt.";
            stopSelf();
            return;
        }

        resetState();
        startMs = System.currentTimeMillis();
        running = true;
        stopRequested = false;
        startForeground(NOTIFICATION_ID, buildNotification("Nachtmessung startet …"));

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HDFlowHRV:NightAudio");
            wakeLock.acquire(12 * 60 * 60 * 1000L);
        }

        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int buffer = Math.max(min, SAMPLE_RATE * 2);
        try {
            audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, buffer);
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("AudioRecord nicht initialisiert");
            audioRecord.startRecording();
        } catch (Exception e) {
            lastError = "Mikrofonstart fehlgeschlagen: " + e.getMessage();
            running = false;
            releaseHardware();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            broadcastUpdate();
            return;
        }

        captureThread = new Thread(this::captureLoop, "HDFlowNightAudio");
        captureThread.start();
        broadcastUpdate();
    }

    private void resetState() {
        currentDb = Double.NaN;
        thresholdDb = -48.0;
        eventCount = 0;
        coveragePct = 0.0;
        lastError = "";
        recentLevels.clear();
        while (storedLevels.length() > 0) storedLevels.remove(storedLevels.length() - 1);
        while (events.length() > 0) events.remove(events.length() - 1);
        quietStart = 0L;
        quietPreActive = false;
        lastActive = 0L;
        oneSecondSamples = 0L;
        oneSecondSquares = 0.0;
        processedSeconds = 0L;
        lastStoredSecond = -99L;
    }

    private void captureLoop() {
        short[] buffer = new short[2048];
        long nextSecond = System.currentTimeMillis() + 1000L;
        try {
            while (!stopRequested && audioRecord != null) {
                int n = audioRecord.read(buffer, 0, buffer.length);
                if (n > 0) {
                    for (int i = 0; i < n; i++) {
                        double x = buffer[i] / 32768.0;
                        oneSecondSquares += x * x;
                    }
                    oneSecondSamples += n;
                }
                long now = System.currentTimeMillis();
                if (now >= nextSecond) {
                    analyzeSecond(now);
                    do { nextSecond += 1000L; } while (nextSecond <= now);
                }
            }
        } catch (Exception e) {
            lastError = "Audiomessung unterbrochen: " + e.getMessage();
        }
    }

    private void analyzeSecond(long now) {
        if (oneSecondSamples <= 0) return;
        double rms = Math.sqrt(oneSecondSquares / oneSecondSamples);
        double db = rms > 0 ? Math.max(-100.0, 20.0 * Math.log10(rms)) : -100.0;
        oneSecondSquares = 0.0;
        oneSecondSamples = 0L;
        processedSeconds++;

        currentDb = db;
        recentLevels.addLast(db);
        while (recentLevels.size() > 120) recentLevels.removeFirst();
        thresholdDb = adaptiveThreshold();

        long sec = Math.max(0, Math.round((now - startMs) / 1000.0));
        if (sec - lastStoredSecond >= 5) {
            JSONArray row = new JSONArray(); row.put(sec); row.put(Double.valueOf(round1(db))); storedLevels.put(row); lastStoredSecond = sec;
        }

        boolean active = db > thresholdDb;
        if (active) {
            if (quietStart > 0) {
                double dur = (now - quietStart) / 1000.0;
                if (dur >= 10.0 && dur <= 90.0 && quietPreActive && db > thresholdDb + 3.0) {
                    try {
                        JSONObject ev = new JSONObject();
                        ev.put("startIso", Instant.ofEpochMilli(quietStart).toString());
                        ev.put("endIso", Instant.ofEpochMilli(now).toString());
                        ev.put("startSec", Math.round((quietStart - startMs) / 1000.0));
                        ev.put("durationSec", round1(dur));
                        ev.put("reboundDb", round1(db));
                        ev.put("thresholdDb", round1(thresholdDb));
                        events.put(ev);
                        eventCount = events.length();
                    } catch (Exception ignored) {}
                }
                quietStart = 0L;
                quietPreActive = false;
            }
            lastActive = now;
        } else if (quietStart == 0L) {
            quietStart = now;
            quietPreActive = lastActive > 0L && (now - lastActive) <= 12000L;
        }

        double elapsed = Math.max(1.0, (now - startMs) / 1000.0);
        coveragePct = Math.min(100.0, 100.0 * processedSeconds / elapsed);
        if (processedSeconds % 30 == 0) updateNotification();
        broadcastUpdate();
    }

    private double adaptiveThreshold() {
        if (recentLevels.isEmpty()) return -48.0;
        List<Double> x = new ArrayList<>(recentLevels);
        Collections.sort(x);
        double pos = (x.size() - 1) * 0.25;
        int lo = (int) Math.floor(pos), hi = (int) Math.ceil(pos);
        double q = lo == hi ? x.get(lo) : x.get(lo) + (x.get(hi) - x.get(lo)) * (pos - lo);
        return Math.max(-72.0, Math.min(-28.0, q + 7.0));
    }

    private synchronized void stopCaptureAndFinish() {
        if (!running && audioRecord == null) { stopSelf(); return; }
        stopRequested = true;
        try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
        try { if (captureThread != null && Thread.currentThread() != captureThread) captureThread.join(1500); } catch (Exception ignored) {}

        long stopMs = System.currentTimeMillis();
        running = false;
        String session = buildSession(stopMs);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_LAST_SESSION, session).apply();
        releaseHardware();
        stopForeground(STOP_FOREGROUND_REMOVE);

        Intent done = new Intent(ACTION_STOPPED); done.setPackage(getPackageName()); sendBroadcast(done);
        stopSelf();
    }

    private String buildSession(long stopMs) {
        try {
            double durationSec = Math.max(0.0, (stopMs - startMs) / 1000.0);
            double hours = durationSec / 3600.0;
            JSONObject s = new JSONObject();
            s.put("id", "night-android-" + startMs);
            s.put("date", new SimpleDateFormat("yyyy-MM-dd", Locale.GERMANY).format(new Date(stopMs)));
            s.put("startIso", Instant.ofEpochMilli(startMs).toString());
            s.put("stopIso", Instant.ofEpochMilli(stopMs).toString());
            s.put("durationSec", Math.round(durationSec));
            s.put("coveragePct", round1(coveragePct));
            s.put("levels", storedLevels);
            s.put("events", events);
            s.put("eventRatePerHour", hours > 0 ? round1(eventCount / hours) : JSONObject.NULL);
            s.put("audioFileName", "");
            s.put("algorithm", "Android V1.0 acoustic-gap heuristic · 10–90 s · 5-s level storage");
            s.put("source", "Android AudioRecord");
            return s.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    private void releaseHardware() {
        if (audioRecord != null) {
            try { audioRecord.release(); } catch (Exception ignored) {}
            audioRecord = null;
        }
        captureThread = null;
        if (wakeLock != null) {
            try { if (wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
            wakeLock = null;
        }
    }

    private void broadcastUpdate() {
        Intent i = new Intent(ACTION_UPDATE);
        i.setPackage(getPackageName());
        i.putExtra("json", getStatusJson());
        sendBroadcast(i);
    }

    private void createChannel() {
        NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Nachtmessung", NotificationManager.IMPORTANCE_LOW);
        c.setDescription("Hält die Mikrofonmessung während des Schlafs aktiv.");
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(c);
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("HD FLOW HRV · Nachtmessung")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    private void updateNotification() {
        long sec = startMs > 0 ? Math.max(0, (System.currentTimeMillis() - startMs) / 1000) : 0;
        String text = String.format(Locale.GERMANY, "%02d:%02d h · %d Ereignisse", sec / 3600, (sec % 3600) / 60, eventCount);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private static double round1(double v) { return Math.round(v * 10.0) / 10.0; }
}
