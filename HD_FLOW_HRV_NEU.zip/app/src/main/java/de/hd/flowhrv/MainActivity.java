package de.hd.flowhrv;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_PERMISSIONS = 41;
    private static final int REQ_FILE = 42;

    private static final UUID HEART_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    private static final UUID HEART_MEASUREMENT = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private BluetoothLeScanner bleScanner;
    private BluetoothGatt bluetoothGatt;
    private boolean scanning = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver nightReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (NightAudioService.ACTION_UPDATE.equals(intent.getAction())) {
                String json = intent.getStringExtra("json");
                if (json != null) callJs("window.HDAndroidNightUpdate && window.HDAndroidNightUpdate(" + json + ");");
            } else if (NightAudioService.ACTION_STOPPED.equals(intent.getAction())) {
                syncLastNightSession();
                syncNightStatus();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUserAgentString(s.getUserAgentString() + " HD-FLOW-HRV-Android/1.0");

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                syncNightStatus();
                syncLastNightSession();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallbackNew, FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePathCallbackNew;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                String[] accept = fileChooserParams != null ? fileChooserParams.getAcceptTypes() : null;
                if (accept != null && accept.length > 0) {
                    List<String> types = new ArrayList<>();
                    for (String a : accept) if (a != null && a.contains("/")) types.add(a);
                    if (!types.isEmpty()) intent.putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0]));
                }
                startActivityForResult(intent, REQ_FILE);
                return true;
            }
        });

        IntentFilter filter = new IntentFilter();
        filter.addAction(NightAudioService.ACTION_UPDATE);
        filter.addAction(NightAudioService.ACTION_STOPPED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(nightReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(nightReceiver, filter);

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(nightReceiver); } catch (Exception ignored) {}
        stopBleScan();
        if (bluetoothGatt != null) {
            try { bluetoothGatt.close(); } catch (Exception ignored) {}
            bluetoothGatt = null;
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS) {
            boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            boolean ble = checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
            callJs("window.onAndroidPermissionResult && window.onAndroidPermissionResult(" + mic + "," + ble + ");");
        }
    }

    private void requestNeededPermissions(boolean mic, boolean ble) {
        List<String> p = new ArrayList<>();
        if (mic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            p.add(Manifest.permission.RECORD_AUDIO);
        if (ble) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), REQ_PERMISSIONS);
    }

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasBlePermissions() {
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void callJs(String js) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void syncNightStatus() {
        callJs("window.HDAndroidNightUpdate && window.HDAndroidNightUpdate(" + NightAudioService.getStatusJson() + ");");
    }

    private void syncLastNightSession() {
        String session = NightAudioService.getLastSessionJson(this);
        if (session != null && !session.isEmpty()) {
            callJs("window.HDAndroidNightStopped && window.HDAndroidNightStopped(" + session + ");");
        }
    }

    private void notifyFlowState(boolean connected, String message, String name) {
        try {
            JSONObject j = new JSONObject();
            j.put("connected", connected);
            j.put("message", message == null ? "" : message);
            j.put("name", name == null ? "FLOW" : name);
            callJs("window.onAndroidFlowState && window.onAndroidFlowState(" + j + ");");
        } catch (Exception ignored) {}
    }

    private void startFlowScan() {
        if (!hasBlePermissions()) {
            requestNeededPermissions(false, true);
            notifyFlowState(false, "Bluetooth-Berechtigung wird angefragt. Danach erneut verbinden.", "FLOW");
            return;
        }
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager != null ? manager.getAdapter() : null;
        if (adapter == null || !adapter.isEnabled()) {
            notifyFlowState(false, "Bluetooth ist ausgeschaltet.", "FLOW");
            return;
        }
        bleScanner = adapter.getBluetoothLeScanner();
        if (bleScanner == null) {
            notifyFlowState(false, "Bluetooth-LE-Scanner nicht verfügbar.", "FLOW");
            return;
        }
        stopBleScan();
        scanning = true;
        ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        bleScanner.startScan(null, settings, scanCallback);
        notifyFlowState(false, "Suche FLOW …", "FLOW");
        mainHandler.postDelayed(() -> {
            if (scanning) {
                stopBleScan();
                notifyFlowState(false, "Kein FLOW gefunden. Gerät anlegen/aktivieren und erneut versuchen.", "FLOW");
            }
        }, 15000);
    }

    private void stopBleScan() {
        if (scanning && bleScanner != null && hasBlePermissions()) {
            try { bleScanner.stopScan(scanCallback); } catch (Exception ignored) {}
        }
        scanning = false;
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (!scanning || result == null || !hasBlePermissions()) return;
            BluetoothDevice device = result.getDevice();
            String name = null;
            try { name = device.getName(); } catch (Exception ignored) {}
            if ((name == null || name.isEmpty()) && result.getScanRecord() != null) name = result.getScanRecord().getDeviceName();
            String up = name == null ? "" : name.toUpperCase(Locale.ROOT);
            if (!up.startsWith("FLOW")) return;
            stopBleScan();
            notifyFlowState(false, "FLOW gefunden – verbinde …", name);
            if (bluetoothGatt != null) {
                try { bluetoothGatt.close(); } catch (Exception ignored) {}
            }
            bluetoothGatt = device.connectGatt(MainActivity.this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                if (hasBlePermissions()) gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                notifyFlowState(false, "FLOW getrennt.", "FLOW");
                try { gatt.close(); } catch (Exception ignored) {}
                if (bluetoothGatt == gatt) bluetoothGatt = null;
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS || !hasBlePermissions()) {
                notifyFlowState(false, "Herzfrequenzdienst konnte nicht geöffnet werden.", "FLOW");
                return;
            }
            BluetoothGattService service = gatt.getService(HEART_SERVICE);
            BluetoothGattCharacteristic c = service != null ? service.getCharacteristic(HEART_MEASUREMENT) : null;
            if (c == null) {
                notifyFlowState(false, "FLOW liefert keinen standardisierten RR-Datenkanal.", "FLOW");
                return;
            }
            gatt.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCCD);
            if (d != null) {
                d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                gatt.writeDescriptor(d);
            }
            String name = "FLOW";
            try { if (gatt.getDevice().getName() != null) name = gatt.getDevice().getName(); } catch (Exception ignored) {}
            notifyFlowState(true, "Verbunden. RR-Daten werden empfangen.", name);
        }

        @Override public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            handleHeartPacket(characteristic.getValue());
        }

        @Override public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, byte[] value) {
            handleHeartPacket(value);
        }
    };

    private void handleHeartPacket(byte[] value) {
        if (value == null || value.length < 2) return;
        int flags = value[0] & 0xff;
        boolean hr16 = (flags & 0x01) != 0;
        boolean energy = (flags & 0x08) != 0;
        boolean rrFlag = (flags & 0x10) != 0;
        int p = 1;
        int hr;
        if (hr16) {
            if (p + 1 >= value.length) return;
            hr = (value[p] & 0xff) | ((value[p + 1] & 0xff) << 8);
            p += 2;
        } else {
            hr = value[p] & 0xff;
            p += 1;
        }
        if (energy) p += 2;
        JSONArray rr = new JSONArray();
        if (rrFlag) {
            while (p + 1 < value.length) {
                int raw = (value[p] & 0xff) | ((value[p + 1] & 0xff) << 8);
                rr.put(Double.valueOf(raw * 1000.0 / 1024.0));
                p += 2;
            }
        }
        callJs("window.onAndroidHrPacket && window.onAndroidHrPacket(" + hr + "," + rr + ");");
    }

    private void disconnectFlow() {
        stopBleScan();
        if (bluetoothGatt != null && hasBlePermissions()) {
            try { bluetoothGatt.disconnect(); } catch (Exception ignored) {}
            try { bluetoothGatt.close(); } catch (Exception ignored) {}
            bluetoothGatt = null;
        }
        notifyFlowState(false, "FLOW getrennt.", "FLOW");
    }

    private String saveAndShareText(String name, String mime, String content) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "text/plain" : mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HD_FLOW_HRV");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return "Speichern fehlgeschlagen.";
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) return "Speichern fehlgeschlagen.";
                out.write(content.getBytes(StandardCharsets.UTF_8));
            }
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime == null || mime.isEmpty() ? "text/plain" : mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivity(Intent.createChooser(send, "Datei teilen")); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Gespeichert in Downloads/HD_FLOW_HRV", Toast.LENGTH_LONG).show(); }
            });
            return "Gespeichert: Downloads/HD_FLOW_HRV/" + name;
        } catch (Exception e) {
            return "Fehler: " + e.getMessage();
        }
    }

    public final class AndroidBridge {
        @JavascriptInterface public boolean isNativeApp() { return true; }

        @JavascriptInterface public String micPermissionState() {
            return hasMicPermission() ? "granted" : "prompt";
        }

        @JavascriptInterface public String testMicrophone() {
            if (!hasMicPermission()) {
                runOnUiThread(() -> requestNeededPermissions(true, false));
                return "{\"ok\":false,\"permissionRequested\":true,\"message\":\"Mikrofon-Berechtigung wird angefragt.\"}";
            }
            if (NightAudioService.isRunning()) return "{\"ok\":true,\"message\":\"Mikrofon ist aktiv; Nachtmessung läuft bereits.\"}";
            return NightAudioService.quickMicTest();
        }

        @JavascriptInterface public String startNight(boolean saveAudio) {
            if (!hasMicPermission()) {
                runOnUiThread(() -> requestNeededPermissions(true, false));
                return "{\"ok\":false,\"message\":\"Mikrofon-Berechtigung wird angefragt. Danach Nacht starten erneut drücken.\"}";
            }
            Intent i = new Intent(MainActivity.this, NightAudioService.class);
            i.setAction(NightAudioService.ACTION_START);
            i.putExtra("saveAudio", saveAudio);
            startForegroundService(i);
            try {
                JSONObject j = new JSONObject();
                j.put("ok", true);
                j.put("startMs", System.currentTimeMillis());
                j.put("message", "Native Nachtmessung startet.");
                return j.toString();
            } catch (Exception e) { return "{\"ok\":false}"; }
        }

        @JavascriptInterface public void stopNight() {
            Intent i = new Intent(MainActivity.this, NightAudioService.class);
            i.setAction(NightAudioService.ACTION_STOP);
            startService(i);
        }

        @JavascriptInterface public String getNightStatus() { return NightAudioService.getStatusJson(); }
        @JavascriptInterface public String getLastNightSession() {
            String x = NightAudioService.getLastSessionJson(MainActivity.this);
            return x == null ? "" : x;
        }

        @JavascriptInterface public void connectFlow() {
            runOnUiThread(() -> startFlowScan());
        }

        @JavascriptInterface public void disconnectFlow() {
            runOnUiThread(() -> MainActivity.this.disconnectFlow());
        }

        @JavascriptInterface public String bluetoothPermissionState() {
            return hasBlePermissions() ? "granted" : "prompt";
        }

        @JavascriptInterface public String shareTextFile(String name, String mime, String content) {
            return saveAndShareText(name, mime, content);
        }
    }
}
