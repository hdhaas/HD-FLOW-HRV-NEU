# HD FLOW HRV NEU · Android V1.6.2

Native Android wrapper for the existing HD FLOW HRV interface with two native bridges:

- **FLOW Bluetooth LE** via Android BLE, including standard Heart Rate Service RR intervals.
- **Night audio screening** via `AudioRecord` in a foreground service, so the screen may be off.

The repository/project contains **no personal measurement data**. Existing FLOW/HRV and Garmin data can be restored with the app's JSON import.

## Night screening

The Android service samples microphone level once per second, stores a 5-second level timeline, and flags quiet gaps of 10–90 seconds followed by a clear acoustic rebound. This is a personal screening aid, **not an AHI and not a medical diagnosis**.

## Build

The companion GitHub Actions workflow uses the same toolchain that worked for the earlier Fitness app:

- Java 17
- Android SDK 34 / Build Tools 34.0.0
- Gradle 8.7
- Android Gradle Plugin 8.5.2

Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.


This clean package is the corrected V1.6 Android project and intentionally contains no GitHub workflow file; the workflow belongs in the repository under `.github/workflows/build-apk.yml`.

## Korrektur V1.6.1 (13.10.2026)

- Der Live-Timer und die Live-Audioanzeigen gehen nach *bestätigtem* Stopp auf 00:00:00 bzw. Ruheanzeige zurück. Die abgeschlossene Messdauer bleibt im Nachtprotokoll erhalten.
- Die **Pegel-CSV** exportiert die gespeicherten Mikrofonpegel (Android ungefähr alle 5 Sekunden), auch bei 0 erkannten Ereignissen. Die bisherige Ereignis-CSV bleibt getrennt; sie enthält nur erkannte akustische Muster.
- In der Nacht-Historie lassen sich Ereignis-CSV und Pegel-CSV einzeln exportieren.
- Beim Wiederöffnen der Android-App überschreibt eine ältere abgeschlossene Nacht nicht mehr den Status einer aktuell laufenden Aufnahme.
- Die App warnt deutlich, wenn eine gespeicherte Nacht keine Pegelwerte enthält.

**Hinweis zur Installation:** GitHub Actions erstellt eine Debug-APK. Ein neuer GitHub-Runner kann eine neue Debug-Signatur verwenden; dann lässt sich die APK möglicherweise nicht über die alte App installieren. Vor einer eventuellen Deinstallation immer die vorhandenen Messdaten über **JSON-Backup teilen** sichern. APK-Erstellung und reales Android-Laufzeitverhalten müssen am Gerät getestet werden.

## Android V1.6.2 · Stop/Start-Handshake Fix

- Der Android-Audiodienst meldet `running` erst nach erfolgreichem AudioRecord-Start. Fehler beim Start des Foreground-Dienstes, bei AudioRecord und beim Lesen werden als Fehlerstatus übertragen.
- Die Web-Oberfläche wartet vor Freigabe von Stopp auf die echte Aufnahme-Bestätigung. Über eine fortlaufende Statusabfrage erkennt sie fehlende Start-/Stopp-Bestätigungen und zeigt Fehler statt dauerhaft im Ladezustand zu hängen.
- Nach Stopp wird die gesicherte Nacht über das lokale Backup des nativen Dienstes verifiziert; die Pegelzahl ist im technischen Status sichtbar.
- Beide CSV-Exporte bleiben erhalten. Eine kurze Mikrofon-Testmessung von 20 Sekunden sollte normalerweise mehrere Pegelwerte liefern.

**Hinweis:** Der Runtime-Fix ist statisch geprüft; es kann keine echte Android-Aufnahme ohne Test auf dem Samsung garantiert werden.
