# HD FLOW HRV NEU · Android V1.6

Native Android wrapper for the existing HD FLOW HRV interface with two native bridges:

- **FLOW Bluetooth LE** via Android BLE, including standard Heart Rate Service RR intervals.
- **Night audio screening** via `AudioRecord` in a foreground service, so the screen may be off.

The repository/project contains **no personal measurement data**. Existing FLOW/HRV and Garmin data can be restored with the app's JSON import.

## Night screening

The Android service samples microphone level once per second, stores a 5-second level timeline, and flags quiet gaps of 10–90 seconds followed by a clear acoustic rebound. This is a personal screening aid, **not an AHI and not a medical diagnosis**.

## Build

The companion GitHub Actions workflow uses the same toolchain that worked for the earlier Fitness app:

- Java 17
- Android SDK 34 / Build Tools 34.0.0
- Gradle 8.7
- Android Gradle Plugin 8.5.2

Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.


This clean package is the corrected V1.6 Android project and intentionally contains no GitHub workflow file; the workflow belongs in the repository under `.github/workflows/build-apk.yml`.
